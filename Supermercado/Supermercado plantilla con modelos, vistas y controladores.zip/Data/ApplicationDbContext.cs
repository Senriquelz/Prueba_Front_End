﻿namespace Supermercado.Data
{
    public class ApplicationDbContext
    {
    }
}
