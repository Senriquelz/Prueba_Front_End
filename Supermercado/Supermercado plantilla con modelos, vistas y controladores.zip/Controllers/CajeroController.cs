﻿using Microsoft.AspNetCore.Mvc;

namespace Supermercado.Controllers
{
    public class CajeroController : Controller
    {
        public IActionResult CajeroVenta()
        {
            return View();
        }
    }
}
